from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from .models import Ubicacion, Vehiculo, Cliente, OrdenServicio, Movimiento

# Catalog of default locations
DEFAULT_LOCATIONS = [
    "Recepción",
    "Taller",
    "Patio",
    "Lavado",
    "Patio de lavado",
    "Fuera de sucursal",
]

def run_seed(db: Session):
    """Populate the database with initial data if empty."""
    # Ensure default locations exist (idempotent).
    # NOTE: Some earlier MVP bundles included a DB with only a subset of
    # locations. If a user keeps that DB, we still want the missing default
    # locations to appear in the board and dropdowns.
    existing = {u.nombre for u in db.query(Ubicacion).all()}
    missing = [name for name in DEFAULT_LOCATIONS if name not in existing]
    if missing:
        for name in missing:
            db.add(Ubicacion(nombre=name))
        db.commit()

    # If there are already vehicles, assume seed has run
    if db.query(Vehiculo).count() > 0:
        return

    # Create demo vehicles and clients
    v1 = Vehiculo(placa="XYZ789", vin="VIN0001", marca="Toyota", modelo="Corolla", anio=2020)
    v2 = Vehiculo(placa="ABC123", vin="VIN0002", marca="Chevrolet", modelo="Onix", anio=2021)
    v3 = Vehiculo(placa="LMN456", vin="VIN0003", marca="Renault", modelo="Duster", anio=2019)
    c1 = Cliente(nombre="Ana Pérez", telefono="555-123", email="ana@test.com")
    c2 = Cliente(nombre="Raúl Gómez", telefono="555-456", email="raul@test.com")

    o1 = OrdenServicio(vehiculo=v1, cliente=c1)
    o2 = OrdenServicio(vehiculo=v2, cliente=c2)
    o3 = OrdenServicio(vehiculo=v3, cliente=c1)

    db.add_all([v1, v2, v3, c1, c2, o1, o2, o3])
    db.commit()

    locations = {u.nombre: u for u in db.query(Ubicacion).all()}
    now = datetime.utcnow()

    # Seed movements for each order (coherent sequential timeline)
    def add_movements(order, stages):
        """Stages: list[(location_name, duration_minutes, actor)]
        The last stage is left "active" (no exit time) to populate the board.
        """
        # Build from oldest to newest
        start_time = now - timedelta(minutes=sum(d for _, d, _ in stages))
        t = start_time
        for idx, (loc, duration, actor) in enumerate(stages):
            ts_llegada = t
            t = t + timedelta(minutes=duration)
            ts_salida = t if idx < len(stages) - 1 else None
            db.add(Movimiento(
                orden=order,
                ubicacion=locations[loc],
                ts_llegada=ts_llegada,
                ts_salida=ts_salida,
                actor=actor,
            ))
        order.estado_actual = stages[-1][0]
        db.add(order)
        db.commit()

    add_movements(o1, [("Recepción", 30, "Recepción - demo"), ("Taller", 45, "Taller - demo")])
    add_movements(o2, [("Recepción", 25, "Recepción - demo"), ("Patio", 35, "Patio - demo")])
    add_movements(o3, [("Recepción", 20, "Recepción - demo"), ("Taller", 30, "Taller - demo"), ("Lavado", 25, "Lavado - demo")])
