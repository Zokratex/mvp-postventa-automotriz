from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from .db import Base

class Vehiculo(Base):
    __tablename__ = "vehiculo"
    id = Column(Integer, primary_key=True, index=True)
    placa = Column(String, unique=True, nullable=False)
    vin = Column(String)
    marca = Column(String)
    modelo = Column(String)
    anio = Column(Integer)

    ordenes = relationship("OrdenServicio", back_populates="vehiculo")

class Cliente(Base):
    __tablename__ = "cliente"
    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, nullable=False)
    telefono = Column(String)
    email = Column(String)

    ordenes = relationship("OrdenServicio", back_populates="cliente")

class OrdenServicio(Base):
    __tablename__ = "orden_servicio"
    id = Column(Integer, primary_key=True, index=True)
    vehiculo_id = Column(Integer, ForeignKey("vehiculo.id"), nullable=False)
    cliente_id = Column(Integer, ForeignKey("cliente.id"), nullable=False)
    fecha_creacion = Column(DateTime, default=datetime.utcnow)
    aceptada = Column(Boolean, default=True)
    estado_actual = Column(String)
    observaciones = Column(Text)

    vehiculo = relationship("Vehiculo", back_populates="ordenes")
    cliente = relationship("Cliente", back_populates="ordenes")
    movimientos = relationship("Movimiento", back_populates="orden", order_by="Movimiento.ts_llegada")
    servicios = relationship("OrdenServicioServicio", back_populates="orden")

class Ubicacion(Base):
    __tablename__ = "ubicacion"
    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, unique=True, nullable=False)

    movimientos = relationship("Movimiento", back_populates="ubicacion")

class Movimiento(Base):
    __tablename__ = "movimiento"
    id = Column(Integer, primary_key=True, index=True)
    orden_id = Column(Integer, ForeignKey("orden_servicio.id"), nullable=False)
    ubicacion_id = Column(Integer, ForeignKey("ubicacion.id"), nullable=False)
    ts_llegada = Column(DateTime, default=datetime.utcnow)
    ts_salida = Column(DateTime, nullable=True)
    actor = Column(String)

    orden = relationship("OrdenServicio", back_populates="movimientos")
    ubicacion = relationship("Ubicacion", back_populates="movimientos")
    asignaciones = relationship("Asignacion", back_populates="movimiento")

class Servicio(Base):
    __tablename__ = "servicio"
    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, unique=True, nullable=False)
    descripcion = Column(Text)
    requiere_taller = Column(Boolean)
    requiere_lavado = Column(Boolean)

    ordenes = relationship("OrdenServicioServicio", back_populates="servicio")

class OrdenServicioServicio(Base):
    __tablename__ = "orden_servicio_servicio"
    id = Column(Integer, primary_key=True, index=True)
    orden_id = Column(Integer, ForeignKey("orden_servicio.id"), nullable=False)
    servicio_id = Column(Integer, ForeignKey("servicio.id"), nullable=False)

    orden = relationship("OrdenServicio", back_populates="servicios")
    servicio = relationship("Servicio", back_populates="ordenes")

class Empleado(Base):
    __tablename__ = "empleado"
    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String)
    rol = Column(String)

    asignaciones = relationship("Asignacion", back_populates="empleado")

class Asignacion(Base):
    __tablename__ = "asignacion"
    id = Column(Integer, primary_key=True, index=True)
    mov_id = Column(Integer, ForeignKey("movimiento.id"), nullable=False)
    empleado_id = Column(Integer, ForeignKey("empleado.id"), nullable=False)

    movimiento = relationship("Movimiento", back_populates="asignaciones")
    empleado = relationship("Empleado", back_populates="asignaciones")
