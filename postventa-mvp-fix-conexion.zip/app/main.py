from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from sqlalchemy import text
from datetime import datetime
import os

from .db import Base, engine, get_db, SessionLocal, DB_PATH
from .models import Vehiculo, Cliente, OrdenServicio, Ubicacion, Movimiento
from .seed import run_seed

app = FastAPI(title="Postventa – MVP")

# Allow the UI to call the API even if it is served from another origin/port (e.g. VS Code Live Server)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health():
    return {"ok": True}


@app.get("/api/debug/dbinfo")
def dbinfo():
    """Small diagnostic endpoint to help troubleshooting on user machines."""
    return {
        "db_path": DB_PATH,
        "db_exists": os.path.exists(DB_PATH),
        "utc_now": datetime.utcnow().isoformat(timespec="seconds"),
    }


def _backup_and_reset_db(reason: str) -> None:
    """Make the MVP self-healing.

    If the DB was created by an older MVP version (or got corrupted), SQLite
    won't migrate it automatically. Instead of forcing users to debug, we keep
    a safety backup and rebuild a fresh DB.
    """
    try:
        if os.path.exists(DB_PATH):
            ts = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
            backup_path = f"{DB_PATH}.broken-{ts}"
            # Close any pooled connections before moving the file.
            engine.dispose()
            os.rename(DB_PATH, backup_path)
            print(f"⚠️  DB antigua/corrupta respaldada en: {backup_path} (razón: {reason})")
    except Exception:
        # Best effort only
        return


def ensure_sqlite_schema() -> None:
    """Best-effort migrations for SQLite.

    The MVP evolves quickly; SQLite won't auto-migrate existing tables.
    If a user ran an older version, their local `postventa.db` may be missing
    newer columns (e.g., `movimiento.actor`, `orden_servicio.estado_actual`).

    This function adds missing columns when possible so the UI can load
    and employees can create/move orders without deleting the DB.
    """
    try:
        # Use a transaction so ALTER TABLE changes are persisted reliably.
        with engine.begin() as conn:
            # movimiento.actor
            cols = conn.execute(text("PRAGMA table_info(movimiento)"))
            cols = [r[1] for r in cols.fetchall()] if cols else []
            if cols and "actor" not in cols:
                conn.execute(text("ALTER TABLE movimiento ADD COLUMN actor TEXT"))

            # orden_servicio.estado_actual + observaciones
            cols = conn.execute(text("PRAGMA table_info(orden_servicio)"))
            cols = [r[1] for r in cols.fetchall()] if cols else []
            if cols and "estado_actual" not in cols:
                conn.execute(text("ALTER TABLE orden_servicio ADD COLUMN estado_actual TEXT"))
            if cols and "observaciones" not in cols:
                conn.execute(text("ALTER TABLE orden_servicio ADD COLUMN observaciones TEXT"))
    except Exception:
        # If anything goes wrong, we don't block startup; the user can still
        # delete `postventa.db` and restart.
        return

# Create tables and run lightweight SQLite migrations
def bootstrap_db() -> None:
    """Create tables, migrate missing columns, seed default data.

    This function is defensive: if something goes wrong (schema drift/corruption),
    it will backup the DB and rebuild a clean one so the MVP stays usable.
    """
    try:
        Base.metadata.create_all(bind=engine)
        ensure_sqlite_schema()
        db = SessionLocal()
        try:
            run_seed(db)
        finally:
            db.close()
    except Exception as e:
        _backup_and_reset_db(str(e))
        # Rebuild clean
        Base.metadata.create_all(bind=engine)
        ensure_sqlite_schema()
        db = SessionLocal()
        try:
            run_seed(db)
        finally:
            db.close()


bootstrap_db()

# Serve static files from the parent static directory
static_dir = os.path.join(os.path.dirname(__file__), "..", "static")


def get_current_movement(db: Session, orden_id: int):
    """Return the most recent movement where ts_salida is null."""
    return (
        db.query(Movimiento)
        .filter(Movimiento.orden_id == orden_id, Movimiento.ts_salida == None)
        .order_by(Movimiento.ts_llegada.desc())
        .first()
    )


def close_active_movements(db: Session, orden_id: int, ts: datetime, actor: str | None = None) -> int:
    """Close any active movements for an order (defensive: handles >1 active)."""
    actives = (
        db.query(Movimiento)
        .filter(Movimiento.orden_id == orden_id, Movimiento.ts_salida == None)
        .all()
    )
    for m in actives:
        m.ts_salida = ts
        if actor and not m.actor:
            m.actor = actor
        db.add(m)
    return len(actives)

@app.get("/api/tablero")
def tablero(db: Session = Depends(get_db)):
    """Return active vehicles grouped by their current location."""
    # Build result keys dynamically from DB to keep UI consistent
    loc_names = [u.nombre for u in db.query(Ubicacion).order_by(Ubicacion.nombre.asc()).all()]
    result = {name: [] for name in loc_names}
    # Single query: fetch only active movements and join needed entities
    active_movs = (
        db.query(Movimiento)
        .join(Movimiento.orden)
        .join(OrdenServicio.vehiculo)
        .join(Movimiento.ubicacion)
        .filter(Movimiento.ts_salida == None)
        .all()
    )
    now = datetime.utcnow()
    for m in active_movs:
        location_name = m.ubicacion.nombre
        mins = int((now - m.ts_llegada).total_seconds() // 60)
        result.setdefault(location_name, [])
        result[location_name].append({
            "orden_id": m.orden.id,
            "placa": m.orden.vehiculo.placa,
            "minutos": mins,
            "ts_llegada": m.ts_llegada.isoformat(timespec="minutes"),
        })
    # Sort each column by time descending (most waiting first)
    for k in list(result.keys()):
        result[k] = sorted(result[k], key=lambda x: x.get("minutos", 0), reverse=True)
    return result


@app.get("/api/placas")
def listar_placas(q: str = Query(default="", description="Filtro parcial de placa"), db: Session = Depends(get_db)):
    """Return up to 20 plates for autocomplete."""
    query = db.query(Vehiculo.placa)
    if q:
        query = query.filter(Vehiculo.placa.ilike(f"%{q}%"))
    placas = [r[0] for r in query.order_by(Vehiculo.placa.asc()).limit(20).all()]
    return {"placas": placas}


@app.get("/api/ubicaciones")
def listar_ubicaciones(db: Session = Depends(get_db)):
    """Return the list of available locations (for UI dropdowns/buttons)."""
    ubicaciones = [u.nombre for u in db.query(Ubicacion).order_by(Ubicacion.nombre.asc()).all()]
    return {"ubicaciones": ubicaciones}

@app.get("/api/orden/{orden_id}/estado")
def estado_orden(orden_id: int, db: Session = Depends(get_db)):
    order = db.query(OrdenServicio).get(orden_id)
    if not order:
        raise HTTPException(status_code=404, detail="Orden no encontrada")
    movement = get_current_movement(db, orden_id)
    if not movement:
        return {"orden_id": orden_id, "placa": order.vehiculo.placa, "estado": None}
    return {
        "orden_id": orden_id,
        "placa": order.vehiculo.placa,
        "estado": {
            "ubicacion": movement.ubicacion.nombre,
            "ts_llegada": movement.ts_llegada.isoformat()
        }
    }

@app.get("/api/orden/placa/{placa}")
def buscar_por_placa(placa: str, db: Session = Depends(get_db)):
    vehicle = db.query(Vehiculo).filter(Vehiculo.placa == placa).first()
    if not vehicle:
        raise HTTPException(status_code=404, detail="Vehículo no encontrado")
    order = db.query(OrdenServicio).filter(OrdenServicio.vehiculo_id == vehicle.id).order_by(OrdenServicio.fecha_creacion.desc()).first()
    if not order:
        raise HTTPException(status_code=404, detail="No hay órdenes para esta placa")
    return estado_orden(order.id, db)

@app.get("/api/orden/{orden_id}/timeline")
def timeline(orden_id: int, db: Session = Depends(get_db)):
    order = db.query(OrdenServicio).get(orden_id)
    if not order:
        raise HTTPException(status_code=404, detail="Orden no encontrada")
    movements = []
    for m in order.movimientos:
        dur_min = None
        if m.ts_salida:
            dur_min = int((m.ts_salida - m.ts_llegada).total_seconds() // 60)
        movements.append({
            "ubicacion": m.ubicacion.nombre,
            "llegada": m.ts_llegada.isoformat(timespec="minutes"),
            "salida": m.ts_salida.isoformat(timespec="minutes") if m.ts_salida else None,
            "duracion_min": dur_min,
            "actor": m.actor
        })
    return {"orden_id": order.id, "placa": order.vehiculo.placa, "movimientos": movements}


@app.post("/api/mover/{orden_id}/{ubicacion}")
def mover(orden_id: int, ubicacion: str, actor: str | None = Query(default=None), db: Session = Depends(get_db)):
    order = db.query(OrdenServicio).get(orden_id)
    if not order:
        raise HTTPException(status_code=404, detail="Orden no encontrada")
    location = db.query(Ubicacion).filter(Ubicacion.nombre == ubicacion).first()
    if not location:
        raise HTTPException(status_code=404, detail="Ubicación inválida")
    ts = datetime.utcnow()
    # Close any active movements, then start a new one.
    try:
        closed = close_active_movements(db, order.id, ts=ts, actor=actor)
        new_movement = Movimiento(
            orden=order,
            ubicacion=location,
            ts_llegada=ts,
            actor=actor,
        )
        db.add(new_movement)
        # Keep estado_actual synced for quick reads / reporting
        order.estado_actual = location.nombre
        db.add(order)
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error al mover: {e}")
    return {"orden_id": order.id, "nueva_ubicacion": location.nombre, "cerrados": closed}


@app.post("/api/deshacer/{orden_id}")
def deshacer_ultimo_movimiento(orden_id: int, actor: str | None = Query(default=None), db: Session = Depends(get_db)):
    """Undo the last move (safe for employees).

    Strategy: close the current active movement (duration 0) and reopen the previous closed movement.
    This keeps auditability while letting users quickly correct accidental clicks.
    """
    order = db.query(OrdenServicio).get(orden_id)
    if not order:
        raise HTTPException(status_code=404, detail="Orden no encontrada")

    current = (
        db.query(Movimiento)
        .filter(Movimiento.orden_id == orden_id, Movimiento.ts_salida == None)
        .order_by(Movimiento.ts_llegada.desc())
        .first()
    )
    if not current:
        raise HTTPException(status_code=400, detail="No hay movimiento activo para deshacer")

    previous = (
        db.query(Movimiento)
        .filter(Movimiento.orden_id == orden_id, Movimiento.ts_salida != None)
        .order_by(Movimiento.ts_salida.desc())
        .first()
    )
    if not previous:
        raise HTTPException(status_code=400, detail="No hay movimiento previo para deshacer")

    try:
        # Mark current move as canceled (0 duration) to preserve audit trail
        current.ts_salida = current.ts_llegada
        if actor:
            current.actor = f"{actor} (anulado)"
        else:
            current.actor = (current.actor or "") + (" (anulado)" if current.actor else "anulado")
        db.add(current)

        # Reopen previous
        previous.ts_salida = None
        if actor and not previous.actor:
            previous.actor = actor
        db.add(previous)

        order.estado_actual = previous.ubicacion.nombre
        db.add(order)

        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error al deshacer: {e}")

    return {"orden_id": orden_id, "ubicacion_actual": previous.ubicacion.nombre}


@app.post('/api/finalizar/{orden_id}')
def finalizar_orden(orden_id: int, actor: str | None = Query(default=None), db: Session = Depends(get_db)):
    order = db.query(OrdenServicio).get(orden_id)
    if not order:
        raise HTTPException(status_code=404, detail='Orden no encontrada')
    ts = datetime.utcnow()
    try:
        close_active_movements(db, order.id, ts=ts, actor=actor)
        order.estado_actual = 'Finalizada'
        db.add(order)
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error al finalizar: {e}")
    return {"orden_id": order.id, "status": "finalizada"}

# Pydantic models for creating new entries
class ClienteCreate(BaseModel):
    nombre: str
    telefono: str | None = None
    email: str | None = None

class VehiculoCreate(BaseModel):
    placa: str
    marca: str | None = None
    modelo: str | None = None
    anio: int | None = None

class OrdenCreate(BaseModel):
    cliente: ClienteCreate
    vehiculo: VehiculoCreate

# Endpoint to create a new client
@app.post("/api/cliente")
def create_cliente(cliente: ClienteCreate, db: Session = Depends(get_db)):
    # Check if client with same email exists
    existing = None
    if cliente.email:
        existing = db.query(Cliente).filter(Cliente.email == cliente.email).first()
    if existing:
        return {"id": existing.id, "nombre": existing.nombre, "telefono": existing.telefono, "email": existing.email}
    new_cliente = Cliente(nombre=cliente.nombre, telefono=cliente.telefono, email=cliente.email)
    db.add(new_cliente)
    db.commit()
    db.refresh(new_cliente)
    return {"id": new_cliente.id, "nombre": new_cliente.nombre, "telefono": new_cliente.telefono, "email": new_cliente.email}

# Endpoint to create a new vehicle
@app.post("/api/vehiculo")
def create_vehiculo(vehiculo: VehiculoCreate, db: Session = Depends(get_db)):
    # Check if vehicle with same plate exists
    existing = db.query(Vehiculo).filter(Vehiculo.placa == vehiculo.placa).first()
    if existing:
        return {"id": existing.id, "placa": existing.placa, "marca": existing.marca, "modelo": existing.modelo, "anio": existing.anio}
    new_vehicle = Vehiculo(
        placa=vehiculo.placa,
        vin=None,
        marca=vehiculo.marca,
        modelo=vehiculo.modelo,
        anio=vehiculo.anio
    )
    db.add(new_vehicle)
    db.commit()
    db.refresh(new_vehicle)
    return {"id": new_vehicle.id, "placa": new_vehicle.placa, "marca": new_vehicle.marca, "modelo": new_vehicle.modelo, "anio": new_vehicle.anio}

# Endpoint to create a new order with its initial movement
@app.post("/api/orden")
def create_orden(order_data: OrdenCreate, db: Session = Depends(get_db)):
    """Create a new work order and its initial movement.

    This endpoint used to commit multiple times; if something failed mid-way,
    it could leave partial rows and then the board would error. We now wrap the
    whole operation in a single transaction.
    """

    client_data = order_data.cliente
    vehicle_data = order_data.vehiculo

    # Normalize plate to avoid duplicates like "abc123" vs "ABC123".
    placa = (vehicle_data.placa or "").strip().upper()
    if not placa:
        raise HTTPException(status_code=400, detail="Placa es obligatoria")

    try:
        with db.begin():
            # Create or get client (prefer email, fallback by name+phone)
            cliente_obj = None
            if client_data.email:
                cliente_obj = db.query(Cliente).filter(Cliente.email == client_data.email).first()
            if not cliente_obj:
                cliente_obj = (
                    db.query(Cliente)
                    .filter(Cliente.nombre == client_data.nombre)
                    .filter(Cliente.telefono == (client_data.telefono or None))
                    .first()
                )
            if not cliente_obj:
                cliente_obj = Cliente(
                    nombre=client_data.nombre,
                    telefono=client_data.telefono,
                    email=client_data.email,
                )
                db.add(cliente_obj)

            # Create or get vehicle
            vehiculo_obj = db.query(Vehiculo).filter(Vehiculo.placa == placa).first()
            if not vehiculo_obj:
                vehiculo_obj = Vehiculo(
                    placa=placa,
                    vin=None,
                    marca=vehicle_data.marca,
                    modelo=vehicle_data.modelo,
                    anio=vehicle_data.anio,
                )
                db.add(vehiculo_obj)

            # Create order
            new_order = OrdenServicio(vehiculo=vehiculo_obj, cliente=cliente_obj)
            db.add(new_order)

            # Initial movement: Recepción (tolerant to spelling)
            reception = (
                db.query(Ubicacion)
                .filter(Ubicacion.nombre.in_(["Recepción", "Recepcion", "RECEPCION"]))
                .first()
            )
            if not reception:
                reception = db.query(Ubicacion).order_by(Ubicacion.id.asc()).first()
            if not reception:
                raise HTTPException(status_code=500, detail="No hay ubicaciones configuradas")

            ts = datetime.utcnow()
            db.add(Movimiento(
                orden=new_order,
                ubicacion=reception,
                ts_llegada=ts,
                actor="sistema",
            ))
            new_order.estado_actual = reception.nombre

        # Refresh after commit
        db.refresh(new_order)
        db.refresh(vehiculo_obj)
        db.refresh(cliente_obj)
        return {"orden_id": new_order.id, "vehiculo_id": vehiculo_obj.id, "cliente_id": cliente_obj.id}
    except HTTPException:
        raise
    except Exception as e:
        # Friendly error for UI
        raise HTTPException(status_code=500, detail=f"No se pudo crear la orden: {e}")


class ReporteResponse(BaseModel):
    ubicacion: str
    movimientos_cerrados: int
    duracion_promedio_min: float | None
    duracion_mediana_min: float | None


@app.get("/api/reportes/tiempos")
def reporte_tiempos(
    db: Session = Depends(get_db),
    start: str | None = Query(default=None, description="ISO date/time start"),
    end: str | None = Query(default=None, description="ISO date/time end"),
):
    """Operational report: time spent per location (closed movements only)."""
    # Parse times (best-effort)
    def parse_dt(s: str | None):
        if not s:
            return None
        try:
            return datetime.fromisoformat(s)
        except Exception:
            return None

    start_dt = parse_dt(start)
    end_dt = parse_dt(end)
    q = db.query(Movimiento).join(Movimiento.ubicacion).filter(Movimiento.ts_salida != None)
    if start_dt:
        q = q.filter(Movimiento.ts_llegada >= start_dt)
    if end_dt:
        q = q.filter(Movimiento.ts_salida <= end_dt)

    rows = q.all()
    by_loc: dict[str, list[int]] = {}
    for m in rows:
        dur = int((m.ts_salida - m.ts_llegada).total_seconds() // 60)
        by_loc.setdefault(m.ubicacion.nombre, []).append(max(dur, 0))

    def median(vals: list[int]) -> float | None:
        if not vals:
            return None
        vs = sorted(vals)
        n = len(vs)
        mid = n // 2
        if n % 2 == 1:
            return float(vs[mid])
        return (vs[mid - 1] + vs[mid]) / 2.0

    out = []
    for loc, vals in sorted(by_loc.items(), key=lambda kv: kv[0]):
        avg = (sum(vals) / len(vals)) if vals else None
        out.append({
            "ubicacion": loc,
            "movimientos_cerrados": len(vals),
            "duracion_promedio_min": avg,
            "duracion_mediana_min": median(vals),
        })
    return {"resultados": out, "rango": {"start": start_dt.isoformat() if start_dt else None, "end": end_dt.isoformat() if end_dt else None}}

# Serve static files from the parent static directory (mount after API routes so POST/other methods to /api/* are not intercepted)
app.mount("/", StaticFiles(directory=static_dir, html=True), name="static")
