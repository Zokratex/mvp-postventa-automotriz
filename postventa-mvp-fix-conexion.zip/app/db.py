import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base


"""Database configuration.

The earlier MVP versions used a relative SQLite path (./postventa.db). That
breaks easily if a user runs `uvicorn` from a different working directory, and
it can look like "the board doesn't load" or "can't create orders" because the
app is reading a different DB file than the one you expect.

To make the MVP reliable for any employee, we store the DB next to the project
by default, and allow overriding it with POSTVENTA_DB_PATH.
"""


BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DB_PATH = os.getenv("POSTVENTA_DB_PATH", os.path.join(BASE_DIR, "postventa.db"))

# Note: sqlite:/// uses an absolute path, sqlite:////... for POSIX. SQLAlchemy
# accepts 3 slashes for absolute path strings.
DATABASE_URL = f"sqlite:///{DB_PATH}"


engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},  # needed for SQLite
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """Provide a transactional scope around a series of operations."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
