import shutil
import sqlite3
import datetime
import os

ROOT = os.path.dirname(os.path.dirname(__file__))
DB_PATH = os.path.join(ROOT, 'postventa.db')

if not os.path.exists(DB_PATH):
    print('ERROR: database not found at', DB_PATH)
    raise SystemExit(1)

# Backup
stamp = datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
backup_path = DB_PATH + f'.bak.{stamp}'
shutil.copy2(DB_PATH, backup_path)
print('Backup created at', backup_path)

# Connect and delete rows from tables (keeping ubicacion and servicio)
conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()
try:
    # Ensure foreign keys enforced for integrity while deleting in order
    cur.execute('PRAGMA foreign_keys = ON;')
    conn.commit()

    tables_to_clear = [
        'asignacion',
        'orden_servicio_servicio',
        'movimiento',
        'orden_servicio',
        'vehiculo',
        'cliente',
        'empleado'
    ]

    for t in tables_to_clear:
        cur.execute(f'DELETE FROM {t};')
        conn.commit()
        print(f'Cleared table {t}')

    # Show counts
    print('\nFinal row counts:')
    for row in cur.execute("SELECT name FROM sqlite_master WHERE type='table';"):
        tbl = row[0]
        cnt = cur.execute(f'SELECT COUNT(*) FROM "{tbl}"').fetchone()[0]
        print(f'  {tbl}: {cnt}')

finally:
    conn.close()

print('\nDone. If you want to restore, copy the backup file back to postventa.db')
