import csv
import sqlite3
import shutil
from pathlib import Path
from datetime import datetime
import sys

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / 'postventa.db'
CUSTOMERS_CSV = ROOT / 'data' / 'customers.csv'
CARS_CSV = ROOT / 'data' / 'cars_tracking.csv'

if not DB_PATH.exists():
    print(f"Error: database not found at {DB_PATH}")
    sys.exit(1)

if not CUSTOMERS_CSV.exists():
    print(f"Error: customers CSV not found at {CUSTOMERS_CSV}")
    sys.exit(1)

if not CARS_CSV.exists():
    print(f"Error: cars CSV not found at {CARS_CSV}")
    sys.exit(1)

# Backup
ts = datetime.now().strftime('%Y%m%dT%H%M%S')
backup = ROOT / f'postventa.db.bak.csv_import.{ts}'
shutil.copy2(DB_PATH, backup)
print(f"Backup created: {backup}")

conn = sqlite3.connect(str(DB_PATH))
conn.row_factory = sqlite3.Row
cur = conn.cursor()

inserted_customers = 0
inserted_cars = 0

try:
    # Insert customers
    with CUSTOMERS_CSV.open('r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Normalize values
            cid = row.get('id') or None
            name = row.get('name')
            phone = row.get('phone')
            email = row.get('email')
            preferred_contact = row.get('preferred_contact')
            address = row.get('address')
            consent = row.get('consent_marketing','').strip().lower()
            if consent in ('true','1','t','yes','y'):
                consent_val = 1
            else:
                consent_val = 0
            notes = row.get('notes')
            created_at = row.get('created_at')
            updated_at = row.get('updated_at')

            # Use INSERT OR REPLACE so we won't fail on duplicate PKs
            cur.execute(
                "INSERT OR REPLACE INTO customers(id,name,phone,email,preferred_contact,address,consent_marketing,notes,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (cid,name,phone,email,preferred_contact,address,consent_val,notes,created_at,updated_at)
            )
            inserted_customers += 1

    # Insert cars_tracking
    with CARS_CSV.open('r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cid = row.get('id') or None
            vin = row.get('vin')
            license_plate = row.get('license_plate')
            customer_id = row.get('customer_id') or None
            make = row.get('make')
            model = row.get('model')
            year = row.get('year') or None
            mileage_km = row.get('mileage_km') or None
            last_service_date = row.get('last_service_date')
            next_service_km = row.get('next_service_km') or None
            status = row.get('status')
            assigned_technician = row.get('assigned_technician')
            service_notes = row.get('service_notes')
            created_at = row.get('created_at')
            updated_at = row.get('updated_at')

            # Simple normalization to ints where possible
            try:
                year_val = int(year) if year not in (None,'') else None
            except:
                year_val = None
            try:
                mileage_val = int(mileage_km) if mileage_km not in (None,'') else None
            except:
                mileage_val = None
            try:
                next_km_val = int(next_service_km) if next_service_km not in (None,'') else None
            except:
                next_km_val = None
            try:
                cust_id_val = int(customer_id) if customer_id not in (None,'') else None
            except:
                cust_id_val = None

            cur.execute(
                "INSERT OR REPLACE INTO cars_tracking(id,vin,license_plate,customer_id,make,model,year,mileage_km,last_service_date,next_service_km,status,assigned_technician,service_notes,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (cid,vin,license_plate,cust_id_val,make,model,year_val,mileage_val,last_service_date,next_km_val,status,assigned_technician,service_notes,created_at,updated_at)
            )
            inserted_cars += 1

    conn.commit()

    # Report counts
    cur.execute("SELECT count(*) FROM customers")
    total_customers = cur.fetchone()[0]
    cur.execute("SELECT count(*) FROM cars_tracking")
    total_cars = cur.fetchone()[0]

    print(f"Inserted customers rows: {inserted_customers}")
    print(f"Inserted cars rows: {inserted_cars}")
    print(f"Total customers in DB: {total_customers}")
    print(f"Total cars_tracking in DB: {total_cars}")

finally:
    conn.close()

print('Done.')
