from app.db import SessionLocal
from app.models import OrdenServicio

s = SessionLocal()
orders = s.query(OrdenServicio).all()
print('ORDERS:', len(orders))
for o in orders:
    placa = o.vehiculo.placa if o.vehiculo else 'N/A'
    print(o.id, placa, 'estado:', o.estado_actual)
s.close()
