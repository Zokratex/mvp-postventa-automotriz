"""Reset local SQLite database.

Use this when the MVP was updated and your existing `postventa.db` has an older schema,
or if the board/orders fail due to a corrupted local DB.

Run:
  python scripts/reset_db.py
Then start the app again:
  python -m uvicorn app.main:app --reload
"""

from pathlib import Path


DB_PATH = Path(__file__).resolve().parents[1] / "postventa.db"


def main() -> None:
    if DB_PATH.exists():
        DB_PATH.unlink()
        print(f"✅ Base eliminada: {DB_PATH}")
    else:
        print(f"ℹ️  No existe DB para borrar: {DB_PATH}")


if __name__ == "__main__":
    main()
