import shutil
import sqlite3
import datetime
import os

ROOT = os.path.dirname(os.path.dirname(__file__))
DB_PATH = os.path.join(ROOT, 'postventa.db')

if not os.path.exists(DB_PATH):
    print('ERROR: database not found at', DB_PATH)
    raise SystemExit(1)

# Backup
stamp = datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
backup_path = DB_PATH + f'.bak.delete_orders.{stamp}'
shutil.copy2(DB_PATH, backup_path)
print('Backup created at', backup_path)

conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()
try:
    cur.execute('PRAGMA foreign_keys = ON;')
    conn.commit()

    ids = [1,2,3]
    ids_str = ','.join(str(i) for i in ids)

    # Delete movimientos referencing these orders
    cur.execute(f"DELETE FROM movimiento WHERE orden_id IN ({ids_str});")
    print('Deleted movimientos for orders', ids)
    # Delete orden_servicio_servicio entries
    cur.execute(f"DELETE FROM orden_servicio_servicio WHERE orden_id IN ({ids_str});")
    print('Deleted orden_servicio_servicio for orders', ids)
    # Delete the orders themselves
    cur.execute(f"DELETE FROM orden_servicio WHERE id IN ({ids_str});")
    print('Deleted orden_servicio rows with ids', ids)

    conn.commit()

    print('\nRow counts after deletion:')
    for row in cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"):
        tbl = row[0]
        try:
            cnt = cur.execute(f'SELECT COUNT(*) FROM "{tbl}"').fetchone()[0]
        except Exception as e:
            cnt = f'error: {e}'
        print(f'  {tbl}: {cnt}')

finally:
    conn.close()

print('\nDone. If needed, restore from backup at:', backup_path)
