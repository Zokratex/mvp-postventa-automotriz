import sqlite3
import shutil
from pathlib import Path
from datetime import datetime
import sys

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / 'postventa.db'
SQL_PATH = ROOT / 'sql' / 'tablas.sql'

if not DB_PATH.exists():
    print(f"Error: database not found at {DB_PATH}")
    sys.exit(1)

if not SQL_PATH.exists():
    print(f"Error: SQL file not found at {SQL_PATH}")
    sys.exit(1)

# backup
ts = datetime.now().strftime('%Y%m%dT%H%M%S')
backup = ROOT / f'postventa.db.bak.tablas.{ts}'
shutil.copy2(DB_PATH, backup)
print(f"Backup created: {backup}")

# apply SQL
sql = SQL_PATH.read_text(encoding='utf-8')
conn = sqlite3.connect(str(DB_PATH))
try:
    conn.executescript(sql)
    conn.commit()
    print(f"Applied SQL from {SQL_PATH}")

    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;")
    tables = [r[0] for r in cur.fetchall()]
    print("Tables in DB after import:")
    for t in tables:
        try:
            cur.execute(f"SELECT count(*) FROM {t}")
            cnt = cur.fetchone()[0]
        except Exception as e:
            cnt = f"error: {e}"
        print(f"  {t}: {cnt}")

finally:
    conn.close()

print("Done.")
