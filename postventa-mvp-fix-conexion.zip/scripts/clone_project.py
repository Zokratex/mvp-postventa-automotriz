#!/usr/bin/env python3
"""
Clone this project into a new folder suitable for sharing.
By default it excludes: .venv, postventa.db, and any backup files starting with postventa.db.bak
Usage:
  python scripts/clone_project.py --dest <folder_name> [--include-db]
"""
import argparse
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parent.parent

def copy_project(dest_name: str, include_db: bool = False):
    dest = ROOT.parent / dest_name
    if dest.exists():
        print(f"Destination {dest} already exists. Abort.")
        return 1

    def ignore_patterns(path, names):
        ignore = set()
        # always ignore virtual env
        if '.venv' in names:
            ignore.add('.venv')
        # ignore backups and temporary DBs
        for n in list(names):
            if n.startswith('postventa.db.bak'):
                ignore.add(n)
        # ignore __pycache__
        for n in list(names):
            if n == '__pycache__':
                ignore.add(n)
        # ignore .git if present
        if '.git' in names:
            ignore.add('.git')
        # ignore DB unless requested
        if not include_db and 'postventa.db' in names:
            ignore.add('postventa.db')
        return ignore

    print(f"Copying project from {ROOT} to {dest} (include_db={include_db})")
    try:
        shutil.copytree(ROOT, dest, ignore=ignore_patterns)
    except Exception as e:
        print('Copy failed:', e)
        return 2

    print('Copy complete.')
    return 0

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--dest', required=True, help='Destination folder name (created alongside the current project)')
    p.add_argument('--include-db', action='store_true', help='Include postventa.db in the copy')
    args = p.parse_args()

    rc = copy_project(args.dest, include_db=args.include_db)
    sys.exit(rc)
