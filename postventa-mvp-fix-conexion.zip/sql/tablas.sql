-- Datos ficticios, no reales.

-- Schema compatible con SQLite y Postgres (tipos simples y CHECKs).
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  preferred_contact TEXT NOT NULL CHECK (preferred_contact IN ('phone','email')),
  address TEXT NOT NULL,
  consent_marketing BOOLEAN NOT NULL,
  notes TEXT,
  created_at TEXT NOT NULL,   -- YYYY-MM-DD HH:MM:SS
  updated_at TEXT NOT NULL    -- YYYY-MM-DD HH:MM:SS
);

CREATE TABLE IF NOT EXISTS cars_tracking (
  id INTEGER PRIMARY KEY,
  vin TEXT NOT NULL UNIQUE,
  license_plate TEXT NOT NULL UNIQUE,
  customer_id INTEGER NOT NULL,
  make TEXT NOT NULL,
  model TEXT NOT NULL,
  year INTEGER NOT NULL CHECK (year BETWEEN 1995 AND 2025),
  mileage_km INTEGER NOT NULL CHECK (mileage_km >= 0),
  last_service_date TEXT NOT NULL, -- YYYY-MM-DD
  next_service_km INTEGER NOT NULL CHECK (next_service_km >= 0),
  status TEXT NOT NULL CHECK (status IN ('waiting','in_service','ready','delivered')),
  assigned_technician TEXT,
  service_notes TEXT,
  created_at TEXT NOT NULL,   -- YYYY-MM-DD HH:MM:SS
  updated_at TEXT NOT NULL,   -- YYYY-MM-DD HH:MM:SS
  FOREIGN KEY (customer_id) REFERENCES customers(id)
);
