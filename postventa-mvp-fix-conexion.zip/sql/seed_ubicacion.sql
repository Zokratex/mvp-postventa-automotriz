INSERT INTO ubicacion (nombre) VALUES
('Recepción'),
('Taller'),
('Patio'),
('Lavado'),
('Patio de lavado'),
('Fuera de sucursal');