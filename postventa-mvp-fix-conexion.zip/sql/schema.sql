-- Base de datos para el sistema de postventa
CREATE TABLE IF NOT EXISTS vehiculo (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  placa TEXT UNIQUE NOT NULL,
  vin TEXT,
  marca TEXT,
  modelo TEXT,
  anio INTEGER
);

CREATE TABLE IF NOT EXISTS cliente (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  telefono TEXT,
  email TEXT
);

CREATE TABLE IF NOT EXISTS orden_servicio (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vehiculo_id INTEGER NOT NULL,
  cliente_id INTEGER NOT NULL,
  fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  aceptada BOOLEAN,
  estado_actual TEXT,
  observaciones TEXT,
  FOREIGN KEY (vehiculo_id) REFERENCES vehiculo (id),
  FOREIGN KEY (cliente_id) REFERENCES cliente (id)
);

CREATE TABLE IF NOT EXISTS ubicacion (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS movimiento (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  orden_id INTEGER NOT NULL,
  ubicacion_id INTEGER NOT NULL,
  ts_llegada TIMESTAMP NOT NULL,
  ts_salida TIMESTAMP,
  actor TEXT,
  FOREIGN KEY (orden_id) REFERENCES orden_servicio (id),
  FOREIGN KEY (ubicacion_id) REFERENCES ubicacion (id)
);

CREATE TABLE IF NOT EXISTS servicio (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT UNIQUE NOT NULL,
  descripcion TEXT,
  requiere_taller BOOLEAN,
  requiere_lavado BOOLEAN
);

CREATE TABLE IF NOT EXISTS orden_servicio_servicio (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  orden_id INTEGER NOT NULL,
  servicio_id INTEGER NOT NULL,
  FOREIGN KEY (orden_id) REFERENCES orden_servicio (id),
  FOREIGN KEY (servicio_id) REFERENCES servicio (id)
);

CREATE TABLE IF NOT EXISTS empleado (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT,
  rol TEXT
);

CREATE TABLE IF NOT EXISTS asignacion (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mov_id INTEGER NOT NULL,
  empleado_id INTEGER NOT NULL,
  FOREIGN KEY (mov_id) REFERENCES movimiento (id),
  FOREIGN KEY (empleado_id) REFERENCES empleado (id)
);
